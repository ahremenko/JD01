package by.htp.library.controller.command;

public interface Command {
	public String executeCommand(String request);
}
