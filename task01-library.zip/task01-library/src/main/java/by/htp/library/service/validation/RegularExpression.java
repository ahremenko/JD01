package by.htp.library.service.validation;

public final class RegularExpression {
	private RegularExpression() {}
	public static final String NUMBER_REGULAR = "\\d+";
	public static final String YEAR_REGULAR = "[0-9]{4}";
}
