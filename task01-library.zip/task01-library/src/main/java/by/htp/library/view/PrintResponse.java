package by.htp.library.view;

public final class PrintResponse {
	private PrintResponse() {}
	
	public static void out(String response){
		System.out.println(response);
	}
}
